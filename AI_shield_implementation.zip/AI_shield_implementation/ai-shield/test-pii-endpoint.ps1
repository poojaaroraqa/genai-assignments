# Test script for PII Detection endpoint
Write-Host "Testing PII Detection Endpoint" -ForegroundColor Cyan
Write-Host "================================`n" -ForegroundColor Cyan

# Test 1: PII Detection with multiple PII types
Write-Host "Test 1: Detect PII (Email, Aadhaar, Phone, PAN)" -ForegroundColor Yellow
$body1 = @{
    text = "My email is john.doe@gmail.com and my Aadhaar is 2345 6789 0123. My phone number is 9876543210 and PAN is ABCDE1234F."
} | ConvertTo-Json

try {
    $response1 = Invoke-RestMethod -Uri "http://localhost:4000/api/detect/pii" -Method Post -Body $body1 -ContentType "application/json"
    Write-Host "✓ Status: $($response1.status)" -ForegroundColor Green
    Write-Host "✓ Action: $($response1.action)" -ForegroundColor Green
    Write-Host "✓ Findings: $($response1.detectorResults[0].findings.Count)" -ForegroundColor Green
    Write-Host "✓ Original: $($response1.originalContent)" -ForegroundColor Gray
    Write-Host "✓ Sanitized: $($response1.sanitizedContent)" -ForegroundColor Green
    Write-Host ""
} catch {
    Write-Host "✗ Test 1 Failed: $_" -ForegroundColor Red
}

# Test 2: Clean text (no PII)
Write-Host "Test 2: Clean Text (No PII)" -ForegroundColor Yellow
$body2 = @{
    text = "This is a clean text with no personal information."
} | ConvertTo-Json

try {
    $response2 = Invoke-RestMethod -Uri "http://localhost:4000/api/detect/pii" -Method Post -Body $body2 -ContentType "application/json"
    Write-Host "✓ Status: $($response2.status)" -ForegroundColor Green
    Write-Host "✓ Action: $($response2.action)" -ForegroundColor Green
    Write-Host "✓ Findings: $($response2.detectorResults[0].findings.Count)" -ForegroundColor Green
    Write-Host ""
} catch {
    Write-Host "✗ Test 2 Failed: $_" -ForegroundColor Red
}

# Test 3: Missing text field (validation error)
Write-Host "Test 3: Validation Error (Missing text field)" -ForegroundColor Yellow
$body3 = @{} | ConvertTo-Json

try {
    $response3 = Invoke-RestMethod -Uri "http://localhost:4000/api/detect/pii" -Method Post -Body $body3 -ContentType "application/json" -ErrorAction Stop
    Write-Host "✗ Should have failed but didn't" -ForegroundColor Red
} catch {
    if ($_.Exception.Response.StatusCode -eq 400) {
        Write-Host "✓ Correctly returned 400 Bad Request" -ForegroundColor Green
    } else {
        Write-Host "✗ Unexpected error: $_" -ForegroundColor Red
    }
}

Write-Host "`n================================" -ForegroundColor Cyan
Write-Host "All Tests Completed!" -ForegroundColor Cyan
