# Test script for Token Size Validation endpoint
Write-Host "Testing Token Size Validation Endpoint" -ForegroundColor Cyan
Write-Host "=======================================`n" -ForegroundColor Cyan

# Test 1: Short text within GPT-4 limit (Should ALLOW)
Write-Host "Test 1: Short Text - GPT-4 (Should ALLOW)" -ForegroundColor Yellow
$body1 = @{
    text = "This is a short text that should be well within the token limit for GPT-4 model."
    model = "gpt-4"
} | ConvertTo-Json

try {
    $response1 = Invoke-RestMethod -Uri "http://localhost:4000/api/detect/token" -Method Post -Body $body1 -ContentType "application/json"
    Write-Host "✓ Status: $($response1.status)" -ForegroundColor Green
    Write-Host "✓ Action: $($response1.action)" -ForegroundColor Green
    Write-Host "✓ Token Estimate: $($response1.metadata.tokenEstimate)" -ForegroundColor Green
    Write-Host "✓ Message: $($response1.detectorResults[0].message)" -ForegroundColor Green
    Write-Host "✓ HTTP Status: 200" -ForegroundColor Green
    Write-Host ""
} catch {
    Write-Host "✗ Test 1 Failed: $_" -ForegroundColor Red
}

# Test 2: Text exceeding GPT-3.5 limit (Should BLOCK)
Write-Host "Test 2: Large Text - GPT-3.5-turbo (Should BLOCK)" -ForegroundColor Yellow
# Create text that exceeds 4096 tokens (approximately 16,384+ characters)
$largeText = "Lorem ipsum dolor sit amet, consectetur adipiscing elit. " * 300
$body2 = @{
    text = $largeText
    model = "gpt-3.5-turbo"
} | ConvertTo-Json

try {
    $response2 = Invoke-RestMethod -Uri "http://localhost:4000/api/detect/token" -Method Post -Body $body2 -ContentType "application/json" -ErrorAction Stop
    if ($response2.action -eq "BLOCK") {
        Write-Host "✓ Action: BLOCK" -ForegroundColor Green
        Write-Host "✓ HTTP Status: 422" -ForegroundColor Green
        Write-Host "✓ Token Estimate: $($response2.metadata.tokenEstimate)" -ForegroundColor Green
        Write-Host "✓ Message: $($response2.detectorResults[0].message)" -ForegroundColor Green
        Write-Host "✓ Finding: $($response2.detectorResults[0].findings[0].masked)" -ForegroundColor Green
        Write-Host ""
    } else {
        Write-Host "✗ Expected BLOCK but got $($response2.action)" -ForegroundColor Red
    }
} catch {
    if ($_.Exception.Response.StatusCode -eq 422) {
        Write-Host "✓ Correctly returned 422 Unprocessable Entity" -ForegroundColor Green
        Write-Host ""
    } else {
        Write-Host "✗ Test 2 Failed: $_" -ForegroundColor Red
    }
}

# Test 3: Text with default model
Write-Host "Test 3: Default Model (Should ALLOW)" -ForegroundColor Yellow
$body3 = @{
    text = "Testing with default model configuration for token validation."
} | ConvertTo-Json

try {
    $response3 = Invoke-RestMethod -Uri "http://localhost:4000/api/detect/token" -Method Post -Body $body3 -ContentType "application/json"
    Write-Host "✓ Status: $($response3.status)" -ForegroundColor Green
    Write-Host "✓ Action: $($response3.action)" -ForegroundColor Green
    Write-Host "✓ Model: default" -ForegroundColor Green
    Write-Host "✓ Token Estimate: $($response3.metadata.tokenEstimate)" -ForegroundColor Green
    Write-Host ""
} catch {
    Write-Host "✗ Test 3 Failed: $_" -ForegroundColor Red
}

# Test 4: Claude model with large text (Should ALLOW - 200K limit)
Write-Host "Test 4: Large Text - Claude-3-opus (Should ALLOW)" -ForegroundColor Yellow
$mediumText = "Detailed analysis text. " * 100
$body4 = @{
    text = $mediumText
    model = "claude-3-opus"
} | ConvertTo-Json

try {
    $response4 = Invoke-RestMethod -Uri "http://localhost:4000/api/detect/token" -Method Post -Body $body4 -ContentType "application/json"
    Write-Host "✓ Action: $($response4.action)" -ForegroundColor Green
    Write-Host "✓ Token Estimate: $($response4.metadata.tokenEstimate)" -ForegroundColor Green
    Write-Host "✓ Claude has high token limit (200K)" -ForegroundColor Green
    Write-Host ""
} catch {
    Write-Host "✗ Test 4 Failed: $_" -ForegroundColor Red
}

# Test 5: Text within GPT-4-turbo limit (128K tokens)
Write-Host "Test 5: Medium Text - GPT-4-turbo (Should ALLOW)" -ForegroundColor Yellow
$mediumText2 = "This is a medium-sized text for GPT-4-turbo testing. " * 50
$body5 = @{
    text = $mediumText2
    model = "gpt-4-turbo"
} | ConvertTo-Json

try {
    $response5 = Invoke-RestMethod -Uri "http://localhost:4000/api/detect/token" -Method Post -Body $body5 -ContentType "application/json"
    Write-Host "✓ Action: $($response5.action)" -ForegroundColor Green
    Write-Host "✓ Token Estimate: $($response5.metadata.tokenEstimate)" -ForegroundColor Green
    Write-Host "✓ GPT-4-turbo has high limit (128K tokens)" -ForegroundColor Green
    Write-Host ""
} catch {
    Write-Host "✗ Test 5 Failed: $_" -ForegroundColor Red
}

# Test 6: Missing text field (validation error)
Write-Host "Test 6: Validation Error (Missing text field)" -ForegroundColor Yellow
$body6 = @{ model = "gpt-4" } | ConvertTo-Json

try {
    $response6 = Invoke-RestMethod -Uri "http://localhost:4000/api/detect/token" -Method Post -Body $body6 -ContentType "application/json" -ErrorAction Stop
    Write-Host "✗ Should have failed but didn't" -ForegroundColor Red
} catch {
    if ($_.Exception.Response.StatusCode -eq 400) {
        Write-Host "✓ Correctly returned 400 Bad Request" -ForegroundColor Green
    } else {
        Write-Host "✗ Unexpected error: $_" -ForegroundColor Red
    }
}

Write-Host "`n=======================================`n" -ForegroundColor Cyan
Write-Host "Token Limits by Model:" -ForegroundColor Yellow
Write-Host "  - gpt-4:          8,192 tokens" -ForegroundColor White
Write-Host "  - gpt-4-turbo:    128,000 tokens" -ForegroundColor White
Write-Host "  - gpt-3.5-turbo:  4,096 tokens" -ForegroundColor White
Write-Host "  - claude-3-opus:  200,000 tokens" -ForegroundColor White
Write-Host "  - claude-sonnet:  200,000 tokens" -ForegroundColor White
Write-Host "  - default:        4,096 tokens" -ForegroundColor White
Write-Host "`nEstimation: ~4 characters per token" -ForegroundColor Cyan
Write-Host "All Tests Completed!" -ForegroundColor Cyan
