# Test script for File Validation endpoint
Write-Host "Testing File Validation Endpoint" -ForegroundColor Cyan
Write-Host "=================================`n" -ForegroundColor Cyan

# Create test files
$testDir = "test-files"
if (-not (Test-Path $testDir)) {
    New-Item -ItemType Directory -Path $testDir | Out-Null
}

# Test 1: Valid TXT file (small size)
Write-Host "Test 1: Valid TXT File (Should ALLOW)" -ForegroundColor Yellow
$validTxtPath = Join-Path $testDir "valid-document.txt"
"This is a valid text document for testing." | Out-File -FilePath $validTxtPath -Encoding UTF8

try {
    $response1 = Invoke-RestMethod -Uri "http://localhost:4000/api/detect/file" `
        -Method Post `
        -Form @{ file = Get-Item -Path $validTxtPath } `
        -ContentType "multipart/form-data"
    
    Write-Host "✓ Status: $($response1.status)" -ForegroundColor Green
    Write-Host "✓ Action: $($response1.action)" -ForegroundColor Green
    Write-Host "✓ Filename: $($response1.metadata.filename)" -ForegroundColor Green
    Write-Host "✓ Size: $($response1.metadata.sizeBytes) bytes" -ForegroundColor Green
    Write-Host "✓ MIME Type: $($response1.metadata.mimeType)" -ForegroundColor Green
    Write-Host "✓ HTTP Status: 200" -ForegroundColor Green
    Write-Host ""
} catch {
    Write-Host "✗ Test 1 Failed: $_" -ForegroundColor Red
}

# Test 2: Valid CSV file
Write-Host "Test 2: Valid CSV File (Should ALLOW)" -ForegroundColor Yellow
$validCsvPath = Join-Path $testDir "data.csv"
"Name,Age,City`nJohn,30,NYC`nJane,25,LA" | Out-File -FilePath $validCsvPath -Encoding UTF8

try {
    $response2 = Invoke-RestMethod -Uri "http://localhost:4000/api/detect/file" `
        -Method Post `
        -Form @{ file = Get-Item -Path $validCsvPath }
    
    Write-Host "✓ Action: $($response2.action)" -ForegroundColor Green
    Write-Host "✓ Filename: $($response2.metadata.filename)" -ForegroundColor Green
    Write-Host ""
} catch {
    Write-Host "✗ Test 2 Failed: $_" -ForegroundColor Red
}

# Test 3: Invalid extension (.exe - simulated with .txt renamed)
Write-Host "Test 3: Invalid Extension - .exe (Should BLOCK)" -ForegroundColor Yellow
$invalidExtPath = Join-Path $testDir "malicious.exe"
"This is not really an exe" | Out-File -FilePath $invalidExtPath -Encoding UTF8

try {
    $response3 = Invoke-RestMethod -Uri "http://localhost:4000/api/detect/file" `
        -Method Post `
        -Form @{ file = Get-Item -Path $invalidExtPath } `
        -ErrorAction Stop
    
    if ($response3.action -eq "BLOCK") {
        Write-Host "✓ Action: BLOCK" -ForegroundColor Green
        Write-Host "✓ HTTP Status: 422" -ForegroundColor Green
        Write-Host "✓ Findings: $($response3.detectorResults[0].findings.Count)" -ForegroundColor Green
        Write-Host "✓ Reason: Invalid extension detected" -ForegroundColor Green
        Write-Host ""
    }
} catch {
    if ($_.Exception.Response.StatusCode -eq 422) {
        Write-Host "✓ Correctly returned 422 Unprocessable Entity" -ForegroundColor Green
        Write-Host ""
    } else {
        Write-Host "✗ Test 3 Failed: $_" -ForegroundColor Red
    }
}

# Test 4: Large file (create a file > 5MB)
Write-Host "Test 4: File Too Large - >5MB (Should BLOCK)" -ForegroundColor Yellow
$largePath = Join-Path $testDir "large-file.txt"
$largeContent = "A" * (6 * 1024 * 1024)  # 6MB of 'A' characters
$largeContent | Out-File -FilePath $largePath -Encoding UTF8 -NoNewline

try {
    $response4 = Invoke-RestMethod -Uri "http://localhost:4000/api/detect/file" `
        -Method Post `
        -Form @{ file = Get-Item -Path $largePath } `
        -ErrorAction Stop
    
    if ($response4.action -eq "BLOCK") {
        Write-Host "✓ Action: BLOCK" -ForegroundColor Green
        Write-Host "✓ File size validation working" -ForegroundColor Green
        Write-Host ""
    }
} catch {
    if ($_.Exception.Response.StatusCode -eq 422) {
        Write-Host "✓ Correctly blocked large file (422)" -ForegroundColor Green
        Write-Host ""
    } else {
        Write-Host "Note: Large file test - may hit Multer limit first" -ForegroundColor Yellow
        Write-Host ""
    }
}

# Test 5: Valid JSON file
Write-Host "Test 5: Valid JSON File (Should ALLOW)" -ForegroundColor Yellow
$validJsonPath = Join-Path $testDir "config.json"
'{"name": "test", "value": 123}' | Out-File -FilePath $validJsonPath -Encoding UTF8

try {
    $response5 = Invoke-RestMethod -Uri "http://localhost:4000/api/detect/file" `
        -Method Post `
        -Form @{ file = Get-Item -Path $validJsonPath }
    
    Write-Host "✓ Action: $($response5.action)" -ForegroundColor Green
    Write-Host "✓ JSON file validated successfully" -ForegroundColor Green
    Write-Host ""
} catch {
    Write-Host "✗ Test 5 Failed: $_" -ForegroundColor Red
}

# Test 6: No file provided (validation error)
Write-Host "Test 6: No File Provided (Should return 400)" -ForegroundColor Yellow
try {
    $response6 = Invoke-RestMethod -Uri "http://localhost:4000/api/detect/file" `
        -Method Post `
        -ContentType "multipart/form-data" `
        -ErrorAction Stop
    
    Write-Host "✗ Should have failed but didn't" -ForegroundColor Red
} catch {
    if ($_.Exception.Response.StatusCode -eq 400) {
        Write-Host "✓ Correctly returned 400 Bad Request" -ForegroundColor Green
    } else {
        Write-Host "✗ Unexpected status code" -ForegroundColor Red
    }
}

# Cleanup test files
Write-Host "`n=================================`n" -ForegroundColor Cyan
Write-Host "Cleaning up test files..." -ForegroundColor Yellow
Remove-Item -Path $testDir -Recurse -Force
Write-Host "✓ Test files removed" -ForegroundColor Green
Write-Host "`nValidation Rules Applied:" -ForegroundColor Yellow
Write-Host "  - Allowed extensions: .txt, .pdf, .docx, .csv, .json, .md, .xlsx" -ForegroundColor White
Write-Host "  - Max file size: 5MB" -ForegroundColor White
Write-Host "  - MIME type validation" -ForegroundColor White
Write-Host "`nAll Tests Completed!" -ForegroundColor Cyan
