# Test script for Toxic Content Detection endpoint
Write-Host "Testing Toxic Content Detection Endpoint" -ForegroundColor Cyan
Write-Host "=========================================`n" -ForegroundColor Cyan

# Test 1: High severity threats (BLOCK)
Write-Host "Test 1: High Severity - Threats (Should BLOCK)" -ForegroundColor Yellow
$body1 = @{
    text = "I will kill this project and bomb the server."
} | ConvertTo-Json

try {
    $response1 = Invoke-RestMethod -Uri "http://localhost:4000/api/detect/toxic" -Method Post -Body $body1 -ContentType "application/json" -ErrorAction Stop
    if ($response1.action -eq "BLOCK") {
        Write-Host "✓ Action: BLOCK" -ForegroundColor Green
        Write-Host "✓ HTTP Status: 422" -ForegroundColor Green
        Write-Host "✓ Findings: $($response1.detectorResults[0].findings.Count)" -ForegroundColor Green
        Write-Host "✓ Message: $($response1.detectorResults[0].message)" -ForegroundColor Green
        Write-Host ""
    }
} catch {
    if ($_.Exception.Response.StatusCode -eq 422) {
        Write-Host "✓ Correctly returned 422 Unprocessable Entity" -ForegroundColor Green
        Write-Host ""
    } else {
        Write-Host "✗ Test 1 Failed: $_" -ForegroundColor Red
    }
}

# Test 2: Medium severity harassment (BLOCK)
Write-Host "Test 2: Medium Severity - Harassment (Should BLOCK)" -ForegroundColor Yellow
$body2 = @{
    text = "You are stupid and an idiot for even thinking about this."
} | ConvertTo-Json

try {
    $response2 = Invoke-RestMethod -Uri "http://localhost:4000/api/detect/toxic" -Method Post -Body $body2 -ContentType "application/json" -ErrorAction Stop
    if ($response2.action -eq "BLOCK") {
        Write-Host "✓ Action: BLOCK" -ForegroundColor Green
        Write-Host "✓ Categories: $($response2.detectorResults[0].findings | ForEach-Object { $_.type } | Select-Object -Unique)" -ForegroundColor Green
        Write-Host ""
    }
} catch {
    if ($_.Exception.Response.StatusCode -eq 422) {
        Write-Host "✓ Correctly returned 422" -ForegroundColor Green
        Write-Host ""
    }
}

# Test 3: Mixed severity - high + medium (BLOCK)
Write-Host "Test 3: Mixed Severity - High + Medium (Should BLOCK)" -ForegroundColor Yellow
$body3 = @{
    text = "I will kill this project and you are stupid for suggesting it moron."
} | ConvertTo-Json

try {
    $response3 = Invoke-RestMethod -Uri "http://localhost:4000/api/detect/toxic" -Method Post -Body $body3 -ContentType "application/json" -ErrorAction Stop
    if ($response3.action -eq "BLOCK") {
        Write-Host "✓ Action: BLOCK" -ForegroundColor Green
        Write-Host "✓ Multiple categories detected" -ForegroundColor Green
        Write-Host ""
    }
} catch {
    if ($_.Exception.Response.StatusCode -eq 422) {
        Write-Host "✓ Correctly returned 422" -ForegroundColor Green
        Write-Host ""
    }
}

# Test 4: Low severity profanity (ALLOW)
Write-Host "Test 4: Low Severity - Profanity (Should ALLOW)" -ForegroundColor Yellow
$body4 = @{
    text = "Damn, this is a hell of a project! Crap, I forgot something."
} | ConvertTo-Json

try {
    $response4 = Invoke-RestMethod -Uri "http://localhost:4000/api/detect/toxic" -Method Post -Body $body4 -ContentType "application/json"
    Write-Host "✓ Status: $($response4.status)" -ForegroundColor Green
    Write-Host "✓ Action: $($response4.action)" -ForegroundColor Green
    Write-Host "✓ HTTP Status: 200" -ForegroundColor Green
    Write-Host "✓ Findings: $($response4.detectorResults[0].findings.Count)" -ForegroundColor Green
    Write-Host "✓ Message: $($response4.detectorResults[0].message)" -ForegroundColor Green
    Write-Host "✓ Note: Low severity detected but ALLOWED" -ForegroundColor Cyan
    Write-Host ""
} catch {
    Write-Host "✗ Test 4 Failed: $_" -ForegroundColor Red
}

# Test 5: Clean text (ALLOW)
Write-Host "Test 5: Clean Text - No Toxic Content (Should ALLOW)" -ForegroundColor Yellow
$body5 = @{
    text = "This is a great feature request. I appreciate your feedback and support."
} | ConvertTo-Json

try {
    $response5 = Invoke-RestMethod -Uri "http://localhost:4000/api/detect/toxic" -Method Post -Body $body5 -ContentType "application/json"
    Write-Host "✓ Status: $($response5.status)" -ForegroundColor Green
    Write-Host "✓ Action: $($response5.action)" -ForegroundColor Green
    Write-Host "✓ Findings: $($response5.detectorResults[0].findings.Count)" -ForegroundColor Green
    Write-Host "✓ HTTP Status: 200" -ForegroundColor Green
    Write-Host ""
} catch {
    Write-Host "✗ Test 5 Failed: $_" -ForegroundColor Red
}

# Test 6: Missing text field (validation error)
Write-Host "Test 6: Validation Error (Missing text field)" -ForegroundColor Yellow
$body6 = @{} | ConvertTo-Json

try {
    $response6 = Invoke-RestMethod -Uri "http://localhost:4000/api/detect/toxic" -Method Post -Body $body6 -ContentType "application/json" -ErrorAction Stop
    Write-Host "✗ Should have failed but didn't" -ForegroundColor Red
} catch {
    if ($_.Exception.Response.StatusCode -eq 400) {
        Write-Host "✓ Correctly returned 400 Bad Request" -ForegroundColor Green
    } else {
        Write-Host "✗ Unexpected error: $_" -ForegroundColor Red
    }
}

Write-Host "`n=========================================`n" -ForegroundColor Cyan
Write-Host "Key Feature: Severity-based blocking!" -ForegroundColor Yellow
Write-Host "  - High/Medium severity → BLOCK (422)" -ForegroundColor Red
Write-Host "  - Low severity → ALLOW (200)" -ForegroundColor Green
Write-Host "All Tests Completed!" -ForegroundColor Cyan
