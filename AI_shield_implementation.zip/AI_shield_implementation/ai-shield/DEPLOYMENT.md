# AI-Shield Deployment Guide

This guide covers deploying AI-Shield to production environments including local servers, cloud platforms, and containerized deployments.

## 📋 Table of Contents

1. [Pre-Deployment Checklist](#pre-deployment-checklist)
2. [Environment Configuration](#environment-configuration)
3. [Production Build](#production-build)
4. [Deployment Methods](#deployment-methods)
5. [Security Hardening](#security-hardening)
6. [Monitoring & Logging](#monitoring--logging)
7. [Performance Optimization](#performance-optimization)
8. [Troubleshooting](#troubleshooting)

---

## 🔍 Pre-Deployment Checklist

Before deploying to production, ensure the following:

### ✅ Code Quality
- [ ] All TypeScript compilation passes (`npx tsc --noEmit`)
- [ ] All test scripts pass successfully
- [ ] API collection tests verified in Postman
- [ ] No console.log statements (use logger instead)
- [ ] Error handling covers all edge cases

### ✅ Configuration
- [ ] Production `.env` file configured
- [ ] Detection rules reviewed and finalized
- [ ] File upload limits set appropriately
- [ ] Token limits configured for target models
- [ ] Logging levels set to `info` or `warn`

### ✅ Security
- [ ] Secrets removed from codebase
- [ ] API keys stored securely (environment variables)
- [ ] CORS configured for allowed origins
- [ ] Rate limiting implemented
- [ ] Input validation covers all endpoints

### ✅ Infrastructure
- [ ] Server provisioned (CPU, RAM, Disk)
- [ ] Database setup (if extending with persistence)
- [ ] Load balancer configured (if multi-instance)
- [ ] SSL/TLS certificates obtained
- [ ] DNS records configured

---

## ⚙️ Environment Configuration

### Production `.env` File

Create a `.env.production` file:

```env
# Server Configuration
NODE_ENV=production
PORT=4000
HOST=0.0.0.0

# Logging
LOG_LEVEL=info
LOG_DIR=./logs
LOG_MAX_SIZE=10m
LOG_MAX_FILES=14d

# File Upload
MAX_FILE_SIZE=5242880
UPLOAD_TEMP_DIR=/tmp/ai-shield-uploads

# Rate Limiting (requests per minute)
RATE_LIMIT_WINDOW=60000
RATE_LIMIT_MAX_REQUESTS=100

# CORS
CORS_ORIGIN=https://yourdomain.com
CORS_CREDENTIALS=true

# API Keys (if integrating with external services)
# OPENAI_API_KEY=your-key-here
# ANTHROPIC_API_KEY=your-key-here
```

### Environment-Specific Rules

Consider maintaining separate rule files per environment:
```
rules/
├── pii-rules.json          # Development
├── pii-rules.prod.json     # Production (stricter)
└── pii-rules.staging.json  # Staging
```

Load rules based on `NODE_ENV`:
```typescript
const ruleFile = process.env.NODE_ENV === 'production' 
  ? 'pii-rules.prod.json' 
  : 'pii-rules.json';
```

---

## 🏗️ Production Build

### Step 1: Install Dependencies

```bash
# Install only production dependencies
npm ci --production

# Or install all and prune dev dependencies later
npm install
npm prune --production
```

### Step 2: Compile TypeScript

```bash
# Clean previous build
rm -rf dist/

# Compile TypeScript
npm run build

# Verify compilation
npx tsc --noEmit
```

### Step 3: Test Production Build

```bash
# Set production environment
export NODE_ENV=production

# Start server
npm start

# Test health endpoint
curl http://localhost:4000/health
```

### Step 4: Create Production Bundle (Optional)

```bash
# Create tarball for deployment
npm pack

# Or create custom archive
tar -czf ai-shield-v1.0.0.tar.gz \
  dist/ \
  rules/ \
  package.json \
  package-lock.json \
  .env.production
```

---

## 🚀 Deployment Methods

### Method 1: Traditional Server (Node.js)

#### Using PM2 (Recommended)

```bash
# Install PM2 globally
npm install -g pm2

# Start application with PM2
pm2 start dist/server.js --name ai-shield --instances 2

# Configure auto-restart on system reboot
pm2 startup
pm2 save

# Monitor application
pm2 monit

# View logs
pm2 logs ai-shield

# Stop application
pm2 stop ai-shield
```

**PM2 Ecosystem File** (`ecosystem.config.js`):

```javascript
module.exports = {
  apps: [{
    name: 'ai-shield',
    script: './dist/server.js',
    instances: 2,
    exec_mode: 'cluster',
    env: {
      NODE_ENV: 'production',
      PORT: 4000
    },
    error_file: './logs/pm2-error.log',
    out_file: './logs/pm2-out.log',
    log_date_format: 'YYYY-MM-DD HH:mm:ss Z',
    max_memory_restart: '500M',
    watch: false,
    autorestart: true
  }]
};
```

Start with ecosystem file:
```bash
pm2 start ecosystem.config.js
```

#### Using systemd (Linux)

Create service file: `/etc/systemd/system/ai-shield.service`

```ini
[Unit]
Description=AI-Shield Moderation API Gateway
After=network.target

[Service]
Type=simple
User=nodejs
WorkingDirectory=/opt/ai-shield
Environment=NODE_ENV=production
Environment=PORT=4000
ExecStart=/usr/bin/node dist/server.js
Restart=on-failure
RestartSec=10
StandardOutput=syslog
StandardError=syslog
SyslogIdentifier=ai-shield

[Install]
WantedBy=multi-user.target
```

Enable and start:
```bash
sudo systemctl enable ai-shield
sudo systemctl start ai-shield
sudo systemctl status ai-shield

# View logs
sudo journalctl -u ai-shield -f
```

---

### Method 2: Docker Deployment

#### Dockerfile

Create `Dockerfile`:

```dockerfile
# Build stage
FROM node:20-alpine AS builder

WORKDIR /app

# Copy package files
COPY package*.json ./
COPY tsconfig.json ./

# Install dependencies
RUN npm ci

# Copy source code
COPY src/ ./src/
COPY rules/ ./rules/

# Build TypeScript
RUN npm run build

# Production stage
FROM node:20-alpine

WORKDIR /app

# Install production dependencies only
COPY package*.json ./
RUN npm ci --production && npm cache clean --force

# Copy built application
COPY --from=builder /app/dist ./dist
COPY --from=builder /app/rules ./rules

# Create logs directory
RUN mkdir -p logs

# Non-root user
RUN addgroup -g 1001 nodejs && \
    adduser -D -u 1001 -G nodejs nodejs && \
    chown -R nodejs:nodejs /app

USER nodejs

# Expose port
EXPOSE 4000

# Health check
HEALTHCHECK --interval=30s --timeout=3s --start-period=40s --retries=3 \
  CMD node -e "require('http').get('http://localhost:4000/health', (r) => {process.exit(r.statusCode === 200 ? 0 : 1)})"

# Start application
CMD ["node", "dist/server.js"]
```

#### .dockerignore

Create `.dockerignore`:

```
node_modules
dist
logs
*.log
.env
.env.local
.env.production
*.md
test-*.ps1
AI-Shield-API-Collection.json
.git
.gitignore
```

#### Build & Run

```bash
# Build image
docker build -t ai-shield:1.0.0 .

# Run container
docker run -d \
  --name ai-shield \
  -p 4000:4000 \
  -e NODE_ENV=production \
  -v $(pwd)/logs:/app/logs \
  -v $(pwd)/rules:/app/rules \
  --restart unless-stopped \
  ai-shield:1.0.0

# View logs
docker logs -f ai-shield

# Stop container
docker stop ai-shield
docker rm ai-shield
```

#### Docker Compose

Create `docker-compose.yml`:

```yaml
version: '3.8'

services:
  ai-shield:
    build: .
    container_name: ai-shield
    ports:
      - "4000:4000"
    environment:
      - NODE_ENV=production
      - PORT=4000
    volumes:
      - ./logs:/app/logs
      - ./rules:/app/rules:ro
    restart: unless-stopped
    healthcheck:
      test: ["CMD", "node", "-e", "require('http').get('http://localhost:4000/health')"]
      interval: 30s
      timeout: 3s
      retries: 3
      start_period: 40s
    networks:
      - ai-shield-net

  # Optional: nginx reverse proxy
  nginx:
    image: nginx:alpine
    container_name: ai-shield-nginx
    ports:
      - "80:80"
      - "443:443"
    volumes:
      - ./nginx.conf:/etc/nginx/nginx.conf:ro
      - ./ssl:/etc/nginx/ssl:ro
    depends_on:
      - ai-shield
    restart: unless-stopped
    networks:
      - ai-shield-net

networks:
  ai-shield-net:
    driver: bridge
```

Start with Docker Compose:
```bash
docker-compose up -d

# View logs
docker-compose logs -f

# Stop services
docker-compose down
```

---

### Method 3: Cloud Platform Deployments

#### AWS EC2

1. **Launch EC2 Instance** (t3.medium or higher)
2. **Install Node.js**:
   ```bash
   curl -fsSL https://rpm.nodesource.com/setup_20.x | sudo bash -
   sudo yum install -y nodejs
   ```
3. **Deploy Application**:
   ```bash
   scp -i key.pem ai-shield-v1.0.0.tar.gz ec2-user@<ip>:~
   ssh -i key.pem ec2-user@<ip>
   tar -xzf ai-shield-v1.0.0.tar.gz
   cd ai-shield
   npm ci --production
   pm2 start dist/server.js
   ```
4. **Configure Security Group**: Allow inbound on port 4000

#### AWS ECS (Fargate)

1. **Push Docker image to ECR**:
   ```bash
   aws ecr create-repository --repository-name ai-shield
   docker tag ai-shield:1.0.0 <account>.dkr.ecr.<region>.amazonaws.com/ai-shield:1.0.0
   docker push <account>.dkr.ecr.<region>.amazonaws.com/ai-shield:1.0.0
   ```

2. **Create ECS Task Definition** (JSON):
   ```json
   {
     "family": "ai-shield",
     "networkMode": "awsvpc",
     "requiresCompatibilities": ["FARGATE"],
     "cpu": "512",
     "memory": "1024",
     "containerDefinitions": [{
       "name": "ai-shield",
       "image": "<account>.dkr.ecr.<region>.amazonaws.com/ai-shield:1.0.0",
       "portMappings": [{
         "containerPort": 4000,
         "protocol": "tcp"
       }],
       "environment": [
         {"name": "NODE_ENV", "value": "production"},
         {"name": "PORT", "value": "4000"}
       ],
       "logConfiguration": {
         "logDriver": "awslogs",
         "options": {
           "awslogs-group": "/ecs/ai-shield",
           "awslogs-region": "<region>",
           "awslogs-stream-prefix": "ecs"
         }
       }
     }]
   }
   ```

3. **Create ECS Service** with Application Load Balancer

#### Azure App Service

```bash
# Login to Azure
az login

# Create resource group
az group create --name ai-shield-rg --location eastus

# Create App Service plan
az appservice plan create \
  --name ai-shield-plan \
  --resource-group ai-shield-rg \
  --sku B1 \
  --is-linux

# Create web app
az webapp create \
  --resource-group ai-shield-rg \
  --plan ai-shield-plan \
  --name ai-shield-api \
  --runtime "NODE:20-lts"

# Deploy from zip
zip -r deploy.zip dist/ rules/ package.json
az webapp deployment source config-zip \
  --resource-group ai-shield-rg \
  --name ai-shield-api \
  --src deploy.zip

# Configure environment
az webapp config appsettings set \
  --resource-group ai-shield-rg \
  --name ai-shield-api \
  --settings NODE_ENV=production PORT=4000
```

#### Google Cloud Run

```bash
# Build and push to GCR
gcloud builds submit --tag gcr.io/PROJECT_ID/ai-shield

# Deploy to Cloud Run
gcloud run deploy ai-shield \
  --image gcr.io/PROJECT_ID/ai-shield \
  --platform managed \
  --region us-central1 \
  --allow-unauthenticated \
  --port 4000 \
  --memory 512Mi \
  --cpu 1 \
  --set-env-vars NODE_ENV=production
```

---

## 🔒 Security Hardening

### 1. Reverse Proxy (Nginx)

Create `/etc/nginx/sites-available/ai-shield`:

```nginx
upstream ai_shield_backend {
    least_conn;
    server 127.0.0.1:4000;
    # server 127.0.0.1:4001;  # Add more instances
}

# Rate limiting
limit_req_zone $binary_remote_addr zone=api_limit:10m rate=100r/m;
limit_req_status 429;

server {
    listen 80;
    server_name api.yourdomain.com;
    
    # Redirect HTTP to HTTPS
    return 301 https://$server_name$request_uri;
}

server {
    listen 443 ssl http2;
    server_name api.yourdomain.com;
    
    # SSL Configuration
    ssl_certificate /etc/ssl/certs/yourdomain.crt;
    ssl_certificate_key /etc/ssl/private/yourdomain.key;
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers HIGH:!aNULL:!MD5;
    ssl_prefer_server_ciphers on;
    
    # Security Headers
    add_header Strict-Transport-Security "max-age=31536000; includeSubDomains" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header X-Frame-Options "DENY" always;
    add_header X-XSS-Protection "1; mode=block" always;
    
    # Request size limits
    client_max_body_size 20M;
    client_body_timeout 60s;
    
    # Logging
    access_log /var/log/nginx/ai-shield-access.log;
    error_log /var/log/nginx/ai-shield-error.log;
    
    location / {
        # Rate limiting
        limit_req zone=api_limit burst=20 nodelay;
        
        # Proxy settings
        proxy_pass http://ai_shield_backend;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
        
        # Timeouts
        proxy_connect_timeout 60s;
        proxy_send_timeout 60s;
        proxy_read_timeout 60s;
    }
    
    # Health check endpoint (no rate limit)
    location /health {
        proxy_pass http://ai_shield_backend;
        access_log off;
    }
}
```

Enable configuration:
```bash
sudo ln -s /etc/nginx/sites-available/ai-shield /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl reload nginx
```

### 2. Firewall Configuration

```bash
# UFW (Ubuntu)
sudo ufw allow 22/tcp    # SSH
sudo ufw allow 80/tcp    # HTTP
sudo ufw allow 443/tcp   # HTTPS
sudo ufw deny 4000/tcp   # Block direct access to app
sudo ufw enable

# Verify
sudo ufw status
```

### 3. Application-Level Security

Update `src/app.ts`:

```typescript
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import cors from 'cors';

// Helmet for security headers
app.use(helmet());

// CORS configuration
app.use(cors({
  origin: process.env.CORS_ORIGIN?.split(',') || 'http://localhost:3000',
  credentials: true,
  optionsSuccessStatus: 200
}));

// Rate limiting
const limiter = rateLimit({
  windowMs: parseInt(process.env.RATE_LIMIT_WINDOW || '60000'),
  max: parseInt(process.env.RATE_LIMIT_MAX_REQUESTS || '100'),
  message: 'Too many requests from this IP, please try again later.',
  standardHeaders: true,
  legacyHeaders: false,
});

app.use('/api/', limiter);
```

Install dependencies:
```bash
npm install helmet express-rate-limit cors
npm install --save-dev @types/cors
```

---

## 📊 Monitoring & Logging

### 1. Application Monitoring

#### Using PM2 Plus (Cloud Monitoring)

```bash
# Link PM2 to PM2 Plus
pm2 link <secret> <public>

# Monitor real-time metrics
pm2 monitor
```

#### Custom Health Checks

Create `/health-check.sh`:

```bash
#!/bin/bash
HEALTH_URL="http://localhost:4000/health"
RESPONSE=$(curl -s -o /dev/null -w "%{http_code}" $HEALTH_URL)

if [ $RESPONSE -eq 200 ]; then
    echo "✅ Health check passed"
    exit 0
else
    echo "❌ Health check failed (HTTP $RESPONSE)"
    exit 1
fi
```

Schedule with cron:
```bash
# Add to crontab
*/5 * * * * /opt/ai-shield/health-check.sh >> /var/log/ai-shield-health.log 2>&1
```

### 2. Log Aggregation

#### ELK Stack (Elasticsearch, Logstash, Kibana)

Filebeat configuration (`filebeat.yml`):

```yaml
filebeat.inputs:
- type: log
  enabled: true
  paths:
    - /opt/ai-shield/logs/application-*.log
  fields:
    app: ai-shield
    env: production

output.elasticsearch:
  hosts: ["localhost:9200"]
  index: "ai-shield-%{+yyyy.MM.dd}"
```

#### CloudWatch Logs (AWS)

Install CloudWatch agent:
```bash
sudo yum install amazon-cloudwatch-agent
```

Configure log shipping (`/opt/aws/amazon-cloudwatch-agent/etc/config.json`):
```json
{
  "logs": {
    "logs_collected": {
      "files": {
        "collect_list": [{
          "file_path": "/opt/ai-shield/logs/application-*.log",
          "log_group_name": "/aws/ec2/ai-shield",
          "log_stream_name": "{instance_id}"
        }]
      }
    }
  }
}
```

---

## ⚡ Performance Optimization

### 1. Caching Strategy

**Redis for Rule Caching** (optional enhancement):

```typescript
import Redis from 'ioredis';

const redis = new Redis({
  host: process.env.REDIS_HOST || 'localhost',
  port: parseInt(process.env.REDIS_PORT || '6379'),
  password: process.env.REDIS_PASSWORD
});

// Cache rules for 5 minutes
async loadRules() {
  const cached = await redis.get('pii-rules');
  if (cached) return JSON.parse(cached);
  
  const rules = await this.loadFromFile();
  await redis.setex('pii-rules', 300, JSON.stringify(rules));
  return rules;
}
```

### 2. Node.js Optimization

**Server Configuration**:

```typescript
// src/server.ts
import cluster from 'cluster';
import os from 'os';

if (cluster.isPrimary && process.env.NODE_ENV === 'production') {
  const numCPUs = os.cpus().length;
  console.log(`Master process ${process.pid} is running`);
  
  // Fork workers
  for (let i = 0; i < numCPUs; i++) {
    cluster.fork();
  }
  
  cluster.on('exit', (worker) => {
    console.log(`Worker ${worker.process.pid} died, starting new worker`);
    cluster.fork();
  });
} else {
  // Workers share TCP connection
  startServer();
}
```

### 3. Load Balancing

With PM2 cluster mode:
```bash
pm2 start dist/server.js -i max  # Use all CPUs
```

With Docker and nginx:
```bash
# Scale to 4 instances
docker-compose up -d --scale ai-shield=4
```

---

## 🔧 Troubleshooting

### Common Issues

#### 1. Port Already in Use

```bash
# Find process using port 4000
lsof -i :4000
# Or on Windows
netstat -ano | findstr :4000

# Kill process
kill -9 <PID>
```

#### 2. Module Not Found Errors

```bash
# Clear cache and reinstall
rm -rf node_modules package-lock.json
npm install
npm run build
```

#### 3. High Memory Usage

Check PM2 memory limits:
```bash
# Restart on high memory
pm2 start ecosystem.config.js --max-memory-restart 500M
```

#### 4. File Upload Fails

Verify temp directory permissions:
```bash
sudo mkdir -p /tmp/ai-shield-uploads
sudo chown nodejs:nodejs /tmp/ai-shield-uploads
sudo chmod 755 /tmp/ai-shield-uploads
```

### Debug Mode

Enable debug logging:
```bash
LOG_LEVEL=debug npm start
```

View real-time logs:
```bash
# PM2
pm2 logs ai-shield --lines 100

# Docker
docker logs -f ai-shield

# systemd
sudo journalctl -u ai-shield -f
```

---

## 📈 Performance Benchmarks

Expected performance on typical hardware:

| Metric | Value |
|--------|-------|
| Requests/sec | 500-1000 |
| Avg Response Time | 50-100ms |
| Memory Usage | 150-300MB |
| CPU Usage | 10-30% |

**Load Testing**:

```bash
# Install Apache Bench
sudo apt install apache2-utils

# Test moderate endpoint
ab -n 1000 -c 10 -p test.json -T application/json \
  http://localhost:4000/api/moderate
```

---

## ✅ Production Checklist

Before going live:

- [ ] Load testing completed (1000+ requests)
- [ ] Health checks configured
- [ ] Monitoring dashboards set up
- [ ] Log rotation working
- [ ] Backups configured (rules, config)
- [ ] SSL/TLS certificates installed
- [ ] Rate limiting tested
- [ ] Error alerts configured
- [ ] Documentation updated
- [ ] Rollback plan documented

---

**Deployment complete! 🚀**

For questions or issues, refer to the main README.md or architecture documentation.
