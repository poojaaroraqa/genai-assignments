# Phase 5 Testing Guide - PII Detector

## Overview
Phase 5 implements the **PII (Personally Identifiable Information) Detector** with the first working API endpoint.

## Endpoint
**POST** `/api/detect/pii`

## Features Implemented
- ✅ Base detector abstract class
- ✅ PII detection with 8 pattern types
- ✅ Automatic masking of detected PII
- ✅ Position tracking for each finding
- ✅ Hot-reloadable rules from `pii-rules.json`

## PII Types Detected
1. **Email** - `john@example.com` → `[EMAIL_REDACTED]`
2. **Indian Phone** - `9876543210` → `[PHONE_REDACTED]`
3. **Aadhaar** - `2345 6789 0123` → `[AADHAAR_REDACTED]`
4. **PAN** - `ABCDE1234F` → `[PAN_REDACTED]`
5. **Credit Card** - `4111 1111 1111 1111` → `[CARD_REDACTED]`
6. **SSN** - `123-45-6789` → `[SSN_REDACTED]`
7. **IP Address** - `192.168.1.1` → `[IP_REDACTED]`
8. **Date of Birth** - `15/08/1990` → `[DOB_REDACTED]`

---

## Testing Instructions

### Option 1: Using PowerShell Test Script
```powershell
cd C:\Users\Pooja.Arora\Downloads\AI_shield_implementation\ai-shield

# Start the server in one terminal
npm run dev

# In another terminal, run the test script
.\test-pii-endpoint.ps1
```

### Option 2: Using cURL (PowerShell)
```powershell
# Test with PII
$body = @{
    text = "My email is john.doe@gmail.com and my Aadhaar is 2345 6789 0123"
} | ConvertTo-Json

Invoke-RestMethod -Uri http://localhost:4000/api/detect/pii -Method Post -Body $body -ContentType "application/json"
```

### Option 3: Using Postman/Thunder Client
1. Import `AI-Shield-API-Collection.json`
2. Run the request: **"Phase 5 - Detect PII"**

---

## Expected Response (With PII)

**Request:**
```json
POST http://localhost:4000/api/detect/pii
{
  "text": "My email is john.doe@gmail.com and my Aadhaar is 2345 6789 0123"
}
```

**Response:**
```json
{
  "status": "success",
  "action": "MASK",
  "detectorResults": [
    {
      "detector": "pii",
      "triggered": true,
      "action": "MASK",
      "findings": [
        {
          "type": "email",
          "value": "john.doe@gmail.com",
          "masked": "[EMAIL_REDACTED]",
          "position": { "start": 12, "end": 30 }
        },
        {
          "type": "aadhaar",
          "value": "2345 6789 0123",
          "masked": "[AADHAAR_REDACTED]",
          "position": { "start": 46, "end": 60 }
        }
      ]
    }
  ],
  "sanitizedContent": "My email is [EMAIL_REDACTED] and my Aadhaar is [AADHAAR_REDACTED]",
  "originalContent": "My email is john.doe@gmail.com and my Aadhaar is 2345 6789 0123",
  "metadata": {
    "tokenEstimate": 16,
    "processingTimeMs": 3,
    "timestamp": "2026-07-05T..."
  }
}
```

---

## Expected Response (No PII)

**Request:**
```json
{
  "text": "This is a clean text with no personal information"
}
```

**Response:**
```json
{
  "status": "success",
  "action": "ALLOW",
  "detectorResults": [
    {
      "detector": "pii",
      "triggered": false,
      "action": "ALLOW",
      "findings": []
    }
  ],
  "sanitizedContent": "This is a clean text with no personal information",
  "originalContent": "This is a clean text with no personal information",
  "metadata": {
    "tokenEstimate": 12,
    "processingTimeMs": 1,
    "timestamp": "2026-07-05T..."
  }
}
```

---

## Validation Test

**Missing `text` field should return 400 error:**
```json
POST /api/detect/pii
{}

Response: 400 Bad Request
{
  "status": "error",
  "message": "`text` field is required"
}
```

---

## Approval Gate Checklist

- [ ] Server starts without TypeScript errors
- [ ] `/api/detect/pii` returns MASK action for text with PII
- [ ] Email, Aadhaar, PAN, Phone are correctly detected
- [ ] Sanitized content shows redacted placeholders
- [ ] Clean text returns ALLOW action with no findings
- [ ] Missing `text` field returns 400 error
- [ ] Logs show request and detection info in `logs/moderation.log`

---

**Phase 5 Complete!** ✅
