# Test script for CII Detection endpoint
Write-Host "Testing CII Detection Endpoint" -ForegroundColor Cyan
Write-Host "================================`n" -ForegroundColor Cyan

# Test 1: CII Detection with multiple types
Write-Host "Test 1: Detect CII (Project codename, Internal URL, Salary info, Internal email)" -ForegroundColor Yellow
$body1 = @{
    text = "The project-phoenix roadmap is available at https://intranet.testleaf.com/roadmap. Contact team@internal.com for salary band details."
} | ConvertTo-Json

try {
    $response1 = Invoke-RestMethod -Uri "http://localhost:4000/api/detect/cii" -Method Post -Body $body1 -ContentType "application/json"
    Write-Host "✓ Status: $($response1.status)" -ForegroundColor Green
    Write-Host "✓ Action: $($response1.action)" -ForegroundColor Green
    Write-Host "✓ Findings: $($response1.detectorResults[0].findings.Count)" -ForegroundColor Green
    Write-Host "✓ Original: $($response1.originalContent)" -ForegroundColor Gray
    Write-Host "✓ Sanitized: $($response1.sanitizedContent)" -ForegroundColor Green
    Write-Host ""
} catch {
    Write-Host "✗ Test 1 Failed: $_" -ForegroundColor Red
}

# Test 2: Client name detection
Write-Host "Test 2: Detect CII (Client names)" -ForegroundColor Yellow
$body2 = @{
    text = "We're working with Acme Corp and Globex on this initiative."
} | ConvertTo-Json

try {
    $response2 = Invoke-RestMethod -Uri "http://localhost:4000/api/detect/cii" -Method Post -Body $body2 -ContentType "application/json"
    Write-Host "✓ Status: $($response2.status)" -ForegroundColor Green
    Write-Host "✓ Action: $($response2.action)" -ForegroundColor Green
    Write-Host "✓ Findings: $($response2.detectorResults[0].findings.Count)" -ForegroundColor Green
    Write-Host "✓ Sanitized: $($response2.sanitizedContent)" -ForegroundColor Green
    Write-Host ""
} catch {
    Write-Host "✗ Test 2 Failed: $_" -ForegroundColor Red
}

# Test 3: Clean text (no CII)
Write-Host "Test 3: Clean Text (No CII)" -ForegroundColor Yellow
$body3 = @{
    text = "This is a public announcement with no confidential information."
} | ConvertTo-Json

try {
    $response3 = Invoke-RestMethod -Uri "http://localhost:4000/api/detect/cii" -Method Post -Body $body3 -ContentType "application/json"
    Write-Host "✓ Status: $($response3.status)" -ForegroundColor Green
    Write-Host "✓ Action: $($response3.action)" -ForegroundColor Green
    Write-Host "✓ Findings: $($response3.detectorResults[0].findings.Count)" -ForegroundColor Green
    Write-Host ""
} catch {
    Write-Host "✗ Test 3 Failed: $_" -ForegroundColor Red
}

# Test 4: Missing text field (validation error)
Write-Host "Test 4: Validation Error (Missing text field)" -ForegroundColor Yellow
$body4 = @{} | ConvertTo-Json

try {
    $response4 = Invoke-RestMethod -Uri "http://localhost:4000/api/detect/cii" -Method Post -Body $body4 -ContentType "application/json" -ErrorAction Stop
    Write-Host "✗ Should have failed but didn't" -ForegroundColor Red
} catch {
    if ($_.Exception.Response.StatusCode -eq 400) {
        Write-Host "✓ Correctly returned 400 Bad Request" -ForegroundColor Green
    } else {
        Write-Host "✗ Unexpected error: $_" -ForegroundColor Red
    }
}

Write-Host "`n================================" -ForegroundColor Cyan
Write-Host "All Tests Completed!" -ForegroundColor Cyan
