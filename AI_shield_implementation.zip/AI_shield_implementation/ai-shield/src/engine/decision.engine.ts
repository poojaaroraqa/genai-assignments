import { DetectorResult, DetectorAction, ModerationResponse } from '../types';
import { PiiDetector } from '../detectors/pii.detector';
import { CiiDetector } from '../detectors/cii.detector';

/**
 * Decision Engine
 * Central orchestration logic for combining multiple detector results
 * Determines final action and applies appropriate sanitization
 */
export class DecisionEngine {
  private piiDetector = new PiiDetector();
  private ciiDetector = new CiiDetector();

  /**
   * Resolve final action from multiple detector results
   * Priority: BLOCK > MASK > ALLOW
   * 
   * @param results - Array of detector results from all detectors
   * @returns Final action to take (BLOCK, MASK, or ALLOW)
   */
  resolveAction(results: DetectorResult[]): DetectorAction {
    // If any detector blocks, the final action is BLOCK
    if (results.some(r => r.action === 'BLOCK')) {
      return 'BLOCK';
    }

    // If any detector requires masking, the final action is MASK
    if (results.some(r => r.action === 'MASK')) {
      return 'MASK';
    }

    // If all detectors allow, the final action is ALLOW
    return 'ALLOW';
  }

  /**
   * Apply sanitization (masking) to text for all MASK-action detectors
   * Currently supports PII and CII masking
   * 
   * @param text - Original text to sanitize
   * @param results - Array of detector results
   * @returns Sanitized text with PII/CII masked
   */
  applySanitization(text: string, results: DetectorResult[]): string {
    let sanitized = text;

    // Get all detectors that triggered and require masking
    const maskDetectors = results.filter(r => r.action === 'MASK' && r.triggered);

    // Apply masking for each detector type
    for (const result of maskDetectors) {
      if (result.detector === 'pii') {
        sanitized = this.piiDetector.mask(sanitized);
      }
      if (result.detector === 'cii') {
        sanitized = this.ciiDetector.mask(sanitized);
      }
    }

    return sanitized;
  }

  /**
   * Build unified moderation response from multiple detector results
   * Handles action resolution, sanitization, and metadata generation
   * 
   * @param originalText - Original input text
   * @param results - Array of detector results from all detectors
   * @param startTime - Request start timestamp for performance tracking
   * @param extra - Optional additional response data
   * @returns Complete ModerationResponse object
   */
  buildResponse(
    originalText: string,
    results: DetectorResult[],
    startTime: number,
    extra?: Partial<ModerationResponse>
  ): ModerationResponse {
    // Determine final action based on all detector results
    const action = this.resolveAction(results);

    // Apply sanitization if action is not BLOCK
    // BLOCK actions should not return sanitized content
    const sanitizedContent = action === 'BLOCK'
      ? undefined
      : this.applySanitization(originalText, results);

    // Build complete response
    return {
      status: 'success',
      action,
      detectorResults: results,
      sanitizedContent,
      originalContent: originalText,
      metadata: {
        tokenEstimate: Math.ceil(originalText.length / 4),
        processingTimeMs: Date.now() - startTime,
        timestamp: new Date().toISOString(),
        ...extra?.metadata
      }
    };
  }
}
