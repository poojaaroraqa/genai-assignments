import { Router, Request, Response, NextFunction } from 'express';
import { CiiDetector } from '../../detectors/cii.detector';
import { ModerationResponse } from '../../types';
import logger from '../../utils/logger';

const router = Router();
const detector = new CiiDetector();

/**
 * POST /api/detect/cii
 * Detect and mask Confidential Internal Information (CII) in text
 * 
 * Request Body:
 * {
 *   "text": "The project-phoenix roadmap is available",
 *   "model": "gpt-4" (optional)
 * }
 * 
 * Response: ModerationResponse with MASK action if CII found
 */
router.post('/', (req: Request, res: Response, next: NextFunction): void => {
  try {
    const start = Date.now();
    const { text, model } = req.body as { text: string; model?: string };

    // Validate input
    if (!text) {
      res.status(400).json({
        status: 'error',
        message: '`text` field is required'
      });
      return;
    }

    // Run CII detection
    const result = detector.detect({ text, model });
    
    // Apply masking if CII was detected
    const sanitizedContent = result.triggered ? detector.mask(text) : text;
    
    // Calculate token estimate (rough approximation: 4 chars per token)
    const tokenEstimate = Math.ceil(text.length / 4);

    // Build response
    const response: ModerationResponse = {
      status: 'success',
      action: result.action,
      detectorResults: [result],
      sanitizedContent,
      originalContent: text,
      metadata: {
        tokenEstimate,
        processingTimeMs: Date.now() - start,
        timestamp: new Date().toISOString()
      }
    };

    logger.info('CII detection complete', {
      action: result.action,
      findingsCount: result.findings.length,
      processingTimeMs: response.metadata.processingTimeMs
    });

    res.status(200).json(response);
  } catch (err) {
    next(err);
  }
});

export default router;
