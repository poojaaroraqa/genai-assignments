import { Router, Request, Response, NextFunction } from 'express';
import { TokenDetector } from '../../detectors/token.detector';
import { ModerationResponse } from '../../types';
import logger from '../../utils/logger';

const router = Router();
const detector = new TokenDetector();

/**
 * POST /api/detect/token
 * Validate token size of text against model-specific limits
 * 
 * Request Body:
 * {
 *   "text": "Long text to validate...",
 *   "model": "gpt-4" (optional, defaults to "default")
 * }
 * 
 * Response: ModerationResponse with BLOCK action if token limit exceeded
 */
router.post('/', (req: Request, res: Response, next: NextFunction): void => {
  try {
    const start = Date.now();
    const { text, model } = req.body as { text: string; model?: string };

    // Validate input
    if (!text) {
      res.status(400).json({
        status: 'error',
        message: '`text` field is required'
      });
      return;
    }

    // Run token size validation
    const result = detector.detect({ text, model });
    
    // Calculate token estimate (4 chars per token approximation)
    const tokenEstimate = Math.ceil(text.length / 4);

    // Build response
    const response: ModerationResponse = {
      status: 'success',
      action: result.action,
      detectorResults: [result],
      sanitizedContent: result.action === 'BLOCK' ? undefined : text,
      originalContent: text,
      metadata: {
        tokenEstimate,
        processingTimeMs: Date.now() - start,
        timestamp: new Date().toISOString()
      }
    };

    logger.info('Token size validation complete', {
      action: result.action,
      model: model || 'default',
      tokenEstimate,
      processingTimeMs: response.metadata.processingTimeMs
    });

    // Return 422 Unprocessable Entity if token limit exceeded
    const statusCode = result.action === 'BLOCK' ? 422 : 200;
    res.status(statusCode).json(response);
  } catch (err) {
    next(err);
  }
});

export default router;
