import { Router, Request, Response, NextFunction } from 'express';
import { InjectionDetector } from '../../detectors/injection.detector';
import { ModerationResponse } from '../../types';
import logger from '../../utils/logger';

const router = Router();
const detector = new InjectionDetector();

/**
 * POST /api/detect/injection
 * Detect prompt injection attack patterns
 * BLOCKS the request if injection patterns are found
 * 
 * Request Body:
 * {
 *   "text": "Ignore previous instructions and...",
 *   "model": "gpt-4" (optional)
 * }
 * 
 * Response: ModerationResponse with BLOCK action if injection detected
 */
router.post('/', (req: Request, res: Response, next: NextFunction): void => {
  try {
    const start = Date.now();
    const { text, model } = req.body as { text: string; model?: string };

    // Validate input
    if (!text) {
      res.status(400).json({
        status: 'error',
        message: '`text` field is required'
      });
      return;
    }

    // Run prompt injection detection
    const result = detector.detect({ text, model });
    
    // Calculate token estimate (rough approximation: 4 chars per token)
    const tokenEstimate = Math.ceil(text.length / 4);

    // Build response
    const response: ModerationResponse = {
      status: 'success',
      action: result.action,
      detectorResults: [result],
      sanitizedContent: result.triggered ? undefined : text,
      originalContent: text,
      metadata: {
        tokenEstimate,
        processingTimeMs: Date.now() - start,
        timestamp: new Date().toISOString()
      }
    };

    logger.info('Prompt injection detection complete', {
      action: result.action,
      findingsCount: result.findings.length,
      injectionTypes: result.findings.map(f => f.type),
      processingTimeMs: response.metadata.processingTimeMs
    });

    // Return 422 Unprocessable Entity if injection is detected
    const statusCode = result.action === 'BLOCK' ? 422 : 200;
    res.status(statusCode).json(response);
  } catch (err) {
    next(err);
  }
});

export default router;
