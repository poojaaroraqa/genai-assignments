import { Router, Request, Response, NextFunction } from 'express';
import { SecretDetector } from '../../detectors/secret.detector';
import { ModerationResponse } from '../../types';
import logger from '../../utils/logger';

const router = Router();
const detector = new SecretDetector();

/**
 * POST /api/detect/secret
 * Detect API keys, tokens, and secrets in text
 * BLOCKS the request if secrets are found (does not mask)
 * 
 * Request Body:
 * {
 *   "text": "Use this key: sk-abc123...",
 *   "model": "gpt-4" (optional)
 * }
 * 
 * Response: ModerationResponse with BLOCK action if secrets found
 */
router.post('/', (req: Request, res: Response, next: NextFunction): void => {
  try {
    const start = Date.now();
    const { text, model } = req.body as { text: string; model?: string };

    // Validate input
    if (!text) {
      res.status(400).json({
        status: 'error',
        message: '`text` field is required'
      });
      return;
    }

    // Run secret detection
    const result = detector.detect({ text, model });
    
    // Calculate token estimate (rough approximation: 4 chars per token)
    const tokenEstimate = Math.ceil(text.length / 4);

    // Build response
    const response: ModerationResponse = {
      status: 'success',
      action: result.action,
      detectorResults: [result],
      sanitizedContent: result.triggered ? undefined : text,
      originalContent: text,
      metadata: {
        tokenEstimate,
        processingTimeMs: Date.now() - start,
        timestamp: new Date().toISOString()
      }
    };

    logger.info('Secret detection complete', {
      action: result.action,
      findingsCount: result.findings.length,
      processingTimeMs: response.metadata.processingTimeMs
    });

    // Return 422 Unprocessable Entity if secrets are detected
    const statusCode = result.action === 'BLOCK' ? 422 : 200;
    res.status(statusCode).json(response);
  } catch (err) {
    next(err);
  }
});

export default router;
