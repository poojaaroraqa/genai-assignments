import { Router, Request, Response, NextFunction } from 'express';
import multer from 'multer';
import { FileDetector } from '../../detectors/file.detector';
import logger from '../../utils/logger';

const router = Router();

// Configure Multer to store files in memory
const upload = multer({
  storage: multer.memoryStorage(),
  limits: {
    fileSize: 20 * 1024 * 1024 // 20MB hard limit (before rule validation)
  }
});

const detector = new FileDetector();

/**
 * POST /api/detect/file
 * Validate uploaded file based on extension, MIME type, and size
 * 
 * Request: multipart/form-data
 * - file: The file to validate (field name must be "file")
 * 
 * Response: ModerationResponse with BLOCK action if validation fails
 */
router.post('/', upload.single('file'), (req: Request, res: Response, next: NextFunction): void => {
  try {
    const start = Date.now();

    // Check if file was uploaded
    if (!req.file) {
      res.status(400).json({
        status: 'error',
        message: 'No file uploaded. Use multipart/form-data with field name "file"'
      });
      return;
    }

    // Run file validation
    const result = detector.detect({}, req.file);

    // Build response
    const response = {
      status: 'success',
      action: result.action,
      detectorResults: [result],
      metadata: {
        filename: req.file.originalname,
        sizeBytes: req.file.size,
        mimeType: req.file.mimetype,
        tokenEstimate: 0,
        processingTimeMs: Date.now() - start,
        timestamp: new Date().toISOString()
      }
    };

    logger.info('File validation complete', {
      action: result.action,
      filename: req.file.originalname,
      sizeBytes: req.file.size,
      mimeType: req.file.mimetype,
      findingsCount: result.findings.length,
      processingTimeMs: response.metadata.processingTimeMs
    });

    // Return 422 Unprocessable Entity if file validation fails
    const statusCode = result.action === 'BLOCK' ? 422 : 200;
    res.status(statusCode).json(response);
  } catch (err) {
    next(err);
  }
});

export default router;
