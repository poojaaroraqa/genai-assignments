import { Router, Request, Response, NextFunction } from 'express';
import { ToxicDetector } from '../../detectors/toxic.detector';
import { ModerationResponse } from '../../types';
import logger from '../../utils/logger';

const router = Router();
const detector = new ToxicDetector();

/**
 * POST /api/detect/toxic
 * Detect toxic content (hate speech, threats, harassment, profanity)
 * Blocks high and medium severity content, allows low severity
 * 
 * Request Body:
 * {
 *   "text": "I will kill this project",
 *   "model": "gpt-4" (optional)
 * }
 * 
 * Response: ModerationResponse with BLOCK action if high/medium severity found
 */
router.post('/', (req: Request, res: Response, next: NextFunction): void => {
  try {
    const start = Date.now();
    const { text, model } = req.body as { text: string; model?: string };

    // Validate input
    if (!text) {
      res.status(400).json({
        status: 'error',
        message: '`text` field is required'
      });
      return;
    }

    // Run toxic content detection
    const result = detector.detect({ text, model });
    
    // Calculate token estimate (rough approximation: 4 chars per token)
    const tokenEstimate = Math.ceil(text.length / 4);

    // Build response
    const response: ModerationResponse = {
      status: 'success',
      action: result.action,
      detectorResults: [result],
      sanitizedContent: result.action === 'BLOCK' ? undefined : text,
      originalContent: text,
      metadata: {
        tokenEstimate,
        processingTimeMs: Date.now() - start,
        timestamp: new Date().toISOString()
      }
    };

    logger.info('Toxic content detection complete', {
      action: result.action,
      findingsCount: result.findings.length,
      severities: result.findings.map(f => f.severity),
      processingTimeMs: response.metadata.processingTimeMs
    });

    // Return 422 Unprocessable Entity if toxic content is blocked
    const statusCode = result.action === 'BLOCK' ? 422 : 200;
    res.status(statusCode).json(response);
  } catch (err) {
    next(err);
  }
});

export default router;
