import { Router } from 'express';
import piiRoute from './detect/pii.route';
import ciiRoute from './detect/cii.route';
import secretRoute from './detect/secret.route';
import toxicRoute from './detect/toxic.route';
import injectionRoute from './detect/injection.route';
import fileRoute from './detect/file.route';
import tokenRoute from './detect/token.route';
import moderateRoute from './moderate.route';

const router = Router();

// Phase 13: Combined Moderation Pipeline
router.use('/moderate', moderateRoute);

// Phase 5: PII Detector
router.use('/detect/pii', piiRoute);

// Phase 6: CII Detector
router.use('/detect/cii', ciiRoute);

// Phase 7: Secret Detector
router.use('/detect/secret', secretRoute);

// Phase 8: Toxic Content Detector
router.use('/detect/toxic', toxicRoute);

// Phase 9: Prompt Injection Detector
router.use('/detect/injection', injectionRoute);

// Phase 10: File Validator
router.use('/detect/file', fileRoute);

// Phase 11: Token Size Validator
router.use('/detect/token', tokenRoute);

export default router;
