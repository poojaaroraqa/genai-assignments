import { Router, Request, Response } from 'express';
import { body, validationResult } from 'express-validator';
import multer from 'multer';
import { PiiDetector } from '../detectors/pii.detector';
import { CiiDetector } from '../detectors/cii.detector';
import { SecretDetector } from '../detectors/secret.detector';
import { ToxicDetector } from '../detectors/toxic.detector';
import { InjectionDetector } from '../detectors/injection.detector';
import { TokenDetector } from '../detectors/token.detector';
import { FileDetector } from '../detectors/file.detector';
import { DecisionEngine } from '../engine/decision.engine';
import { DetectorResult } from '../types';
import logger from '../utils/logger';

const router = Router();
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 20 * 1024 * 1024 } });

// Initialize all detectors
const piiDetector = new PiiDetector();
const ciiDetector = new CiiDetector();
const secretDetector = new SecretDetector();
const toxicDetector = new ToxicDetector();
const injectionDetector = new InjectionDetector();
const tokenDetector = new TokenDetector();
const fileDetector = new FileDetector();
const decisionEngine = new DecisionEngine();

/**
 * POST /api/moderate
 * Combined moderation pipeline - runs all detectors
 * Accepts text and optional file upload
 */
router.post(
  '/',
  upload.single('file'),
  [
    body('text').notEmpty().withMessage('Text is required').isString(),
    body('model').optional().isString()
  ],
  async (req: Request, res: Response) => {
    try {
      const startTime = Date.now();
      
      // Validate request
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
      }

      const { text, model } = req.body;
      const file = req.file;

      logger.info('Moderation request received', {
        textLength: text.length,
        model: model || 'default',
        hasFile: !!file
      });

      const results: DetectorResult[] = [];

      // Run all text-based detectors
      logger.debug('Running PII detector');
      const piiResult = await piiDetector.detect(text);
      results.push(piiResult);

      logger.debug('Running CII detector');
      const ciiResult = await ciiDetector.detect(text);
      results.push(ciiResult);

      logger.debug('Running Secret detector');
      const secretResult = await secretDetector.detect(text);
      results.push(secretResult);

      logger.debug('Running Toxic detector');
      const toxicResult = await toxicDetector.detect(text);
      results.push(toxicResult);

      logger.debug('Running Injection detector');
      const injectionResult = await injectionDetector.detect(text);
      results.push(injectionResult);

      logger.debug('Running Token detector');
      const tokenResult = await tokenDetector.detect(text);
      results.push(tokenResult);

      // Run file detector if file is provided
      if (file) {
        logger.debug('Running File detector');
        const fileResult = await fileDetector.detect({ text }, file);
        results.push(fileResult);
      }

      // Use decision engine to resolve final action
      const response = decisionEngine.buildResponse(text, results, startTime);

      logger.info('Moderation completed', {
        action: response.action,
        detectorsTriggered: results.filter(r => r.triggered).length,
        totalDetectors: results.length
      });

      // Return appropriate status code
      if (response.action === 'BLOCK') {
        return res.status(422).json(response);
      }

      return res.status(200).json(response);

    } catch (error) {
      logger.error('Moderation error:', error);
      return res.status(500).json({ 
        error: 'Internal server error',
        message: error instanceof Error ? error.message : 'Unknown error'
      });
    }
  }
);

export default router;
