import fs from 'fs';
import path from 'path';

const rulesDir = path.resolve(__dirname, '../../rules');
const cache = new Map<string, { data: unknown; mtime: number }>();

/**
 * Hot-reloadable JSON rule loader
 * Caches rules based on file modification time
 * Automatically reloads when file changes are detected
 */
export function loadRules<T>(filename: string): T {
  const filePath = path.join(rulesDir, filename);
  
  if (!fs.existsSync(filePath)) {
    throw new Error(`Rule file not found: ${filename}`);
  }

  const stat = fs.statSync(filePath);
  const mtime = stat.mtimeMs;

  const cached = cache.get(filename);
  
  // Return cached version if file hasn't changed
  if (cached && cached.mtime === mtime) {
    return cached.data as T;
  }

  // Read and parse the file
  const raw = fs.readFileSync(filePath, 'utf-8');
  const data = JSON.parse(raw) as T;
  
  // Update cache with new data and modification time
  cache.set(filename, { data, mtime });

  return data;
}

/**
 * Clear the cache for a specific file or all files
 */
export function clearCache(filename?: string): void {
  if (filename) {
    cache.delete(filename);
  } else {
    cache.clear();
  }
}
