// Core Action Types
export type DetectorAction = 'ALLOW' | 'MASK' | 'BLOCK';
export type SeverityLevel = 'low' | 'medium' | 'high';

// Finding Interface
export interface Finding {
  type: string;
  value: string;
  masked?: string;
  severity?: SeverityLevel;
  position?: { start: number; end: number };
}

// Detector Result Interface
export interface DetectorResult {
  detector: string;
  triggered: boolean;
  action: DetectorAction;
  findings: Finding[];
  message?: string;
}

// Moderation Response Interface
export interface ModerationResponse {
  status: 'success' | 'error';
  action: DetectorAction;
  detectorResults: DetectorResult[];
  sanitizedContent?: string;
  originalContent?: string;
  metadata: {
    tokenEstimate: number;
    processingTimeMs: number;
    timestamp: string;
  };
}

// Moderation Request Interface
export interface ModerationRequest {
  text?: string;
  model?: string;
}

// Rule Type Interfaces
export interface PiiRule {
  type: string;
  pattern: string;
  mask: string;
  action: DetectorAction;
  enabled: boolean;
}

export interface CiiRule {
  type: string;
  keywords?: string[];
  pattern?: string;
  action: DetectorAction;
  enabled: boolean;
}

export interface SecretRule {
  type: string;
  pattern: string;
  action: DetectorAction;
  enabled: boolean;
}

export interface ToxicRule {
  category: string;
  severity: SeverityLevel;
  keywords: string[];
  action: DetectorAction;
  enabled: boolean;
}

export interface InjectionRule {
  type: string;
  patterns: string[];
  action: DetectorAction;
  enabled: boolean;
}

export interface FileRule {
  allowedExtensions: string[];
  allowedMimeTypes: string[];
  maxFileSizeBytes: number;
  action: DetectorAction;
}

export interface TokenRule {
  model: string;
  maxTokens: number;
  charsPerToken: number;
  action: DetectorAction;
}
