import express from 'express';
import cors from 'cors';
import { errorMiddleware } from './middleware/error.middleware';
import { requestLogger } from './middleware/request.logger';
import routes from './routes';
import logger from './utils/logger';

const app = express();

// Middleware
app.use(cors());
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));
app.use(requestLogger);

// Health check endpoint
app.get('/health', (_req, res) => {
  logger.info('Health check requested');
  res.json({ status: 'ok', service: 'AI-Shield', timestamp: new Date().toISOString() });
});

// API Routes
app.use('/api', routes);

// Error handling middleware (must be last)
app.use(errorMiddleware);

export default app;
