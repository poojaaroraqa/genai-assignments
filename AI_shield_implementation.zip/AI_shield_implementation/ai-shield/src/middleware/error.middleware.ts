import { Request, Response, NextFunction } from 'express';
import logger from '../utils/logger';
import { ModerationResponse } from '../types';

/**
 * Global error handling middleware
 * Catches all unhandled errors and returns standardized error response
 */
export function errorMiddleware(
  err: Error,
  _req: Request,
  res: Response,
  _next: NextFunction
): void {
  logger.error('Unhandled error', {
    message: err.message,
    stack: err.stack,
    name: err.name
  });

  const errorResponse: ModerationResponse = {
    status: 'error',
    action: 'BLOCK',
    detectorResults: [],
    sanitizedContent: undefined,
    originalContent: undefined,
    metadata: {
      tokenEstimate: 0,
      processingTimeMs: 0,
      timestamp: new Date().toISOString()
    }
  };

  // Send error response
  res.status(500).json({
    ...errorResponse,
    message: process.env.NODE_ENV === 'production' 
      ? 'Internal server error' 
      : err.message
  });
}
