import { Request, Response, NextFunction } from 'express';
import logger from '../utils/logger';

/**
 * Request logging middleware
 * Logs incoming requests with method, path, and content type
 */
export function requestLogger(req: Request, _res: Response, next: NextFunction): void {
  const { method, path, ip } = req;
  const contentType = req.headers['content-type'] || 'none';
  
  logger.info('Incoming request', {
    method,
    path,
    ip,
    contentType,
    userAgent: req.headers['user-agent']
  });
  
  next();
}
