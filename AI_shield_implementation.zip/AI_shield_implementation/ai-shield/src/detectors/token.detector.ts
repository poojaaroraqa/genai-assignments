import { BaseDetector } from './base.detector';
import { DetectorResult, ModerationRequest, TokenRule } from '../types';
import { loadRules } from '../config/loader';

interface TokenConfig {
  enabled: boolean;
  charsPerToken: number;
  models: TokenRule[];
}

/**
 * Token Size Validator
 * Estimates token count and validates against model-specific limits
 * Uses character-based approximation (default: 4 chars per token)
 * BLOCKS requests that exceed the token limit for the specified model
 */
export class TokenDetector extends BaseDetector {
  name = 'token';

  /**
   * Detect if text exceeds token limit for specified model
   * @param request - Moderation request containing text and optional model
   * @returns DetectorResult with BLOCK action if token limit exceeded
   */
  detect(request: ModerationRequest): DetectorResult {
    const config = loadRules<TokenConfig>('token-rules.json');
    
    if (!config.enabled) {
      return this.buildResult(false, 'ALLOW', []);
    }

    const text = request.text || '';
    const model = request.model || 'default';
    
    // Estimate token count based on character length
    const estimatedTokens = Math.ceil(text.length / config.charsPerToken);

    // Find model-specific rule or fall back to default
    const modelRule = config.models.find(m => m.model === model)
      ?? config.models.find(m => m.model === 'default');

    if (!modelRule) {
      return this.buildResult(false, 'ALLOW', [], 'No token limit configured for model');
    }

    // Check if token limit is exceeded
    const exceeded = estimatedTokens > modelRule.maxTokens;

    if (exceeded) {
      return this.buildResult(
        true,
        'BLOCK',
        [{
          type: 'token_limit_exceeded',
          value: `${estimatedTokens} tokens`,
          masked: `Max allowed for ${model}: ${modelRule.maxTokens} tokens`
        }],
        `Token limit exceeded: ${estimatedTokens} > ${modelRule.maxTokens} for model ${model}`
      );
    }

    return this.buildResult(
      false,
      'ALLOW',
      [],
      `Token count within limit: ${estimatedTokens}/${modelRule.maxTokens} for model ${model}`
    );
  }
}
