import { BaseDetector } from './base.detector';
import { DetectorResult, ModerationRequest, Finding, InjectionRule } from '../types';
import { loadRules } from '../config/loader';

interface InjectionConfig {
  enabled: boolean;
  defaultAction: string;
  rules: InjectionRule[];
}

/**
 * Prompt Injection Detector
 * Detects prompt injection attack patterns including:
 * - Ignore instructions attempts
 * - Role switch/jailbreak attempts
 * - System override attempts
 * - Data exfiltration attempts
 * BLOCKS requests when injection patterns are detected
 */
export class InjectionDetector extends BaseDetector {
  name = 'injection';

  /**
   * Detect prompt injection patterns in the provided text
   * @param request - Moderation request containing text to scan
   * @returns DetectorResult with findings and BLOCK action if injection detected
   */
  detect(request: ModerationRequest): DetectorResult {
    const config = loadRules<InjectionConfig>('injection-rules.json');
    
    if (!config.enabled) {
      return this.buildResult(false, 'ALLOW', []);
    }

    const text = request.text?.toLowerCase() || '';
    const findings: Finding[] = [];

    // Check each injection rule type
    for (const rule of config.rules) {
      if (!rule.enabled) continue;
      
      // Check all patterns for this rule type
      for (const pattern of rule.patterns) {
        if (text.includes(pattern.toLowerCase())) {
          findings.push({
            type: rule.type,
            value: pattern
          });
        }
      }
    }

    const triggered = findings.length > 0;
    
    return this.buildResult(
      triggered,
      triggered ? 'BLOCK' : 'ALLOW',
      findings,
      triggered ? 'Request blocked: prompt injection detected' : undefined
    );
  }
}
