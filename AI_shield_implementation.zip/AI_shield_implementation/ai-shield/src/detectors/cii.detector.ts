import { BaseDetector } from './base.detector';
import { DetectorResult, ModerationRequest, Finding, CiiRule } from '../types';
import { loadRules } from '../config/loader';

interface CiiConfig {
  enabled: boolean;
  defaultAction: string;
  rules: CiiRule[];
}

/**
 * CII (Confidential Internal Information) Detector
 * Detects and masks company-sensitive information like project codenames,
 * internal URLs, salary info, client names, and internal email addresses
 */
export class CiiDetector extends BaseDetector {
  name = 'cii';

  /**
   * Detect CII in the provided text
   * @param request - Moderation request containing text to scan
   * @returns DetectorResult with findings and MASK action if CII detected
   */
  detect(request: ModerationRequest): DetectorResult {
    const config = loadRules<CiiConfig>('cii-rules.json');
    
    if (!config.enabled) {
      return this.buildResult(false, 'ALLOW', []);
    }

    const text = request.text || '';
    const findings: Finding[] = [];

    // Iterate through all CII rules
    for (const rule of config.rules) {
      if (!rule.enabled) continue;

      // Check keyword-based rules
      if (rule.keywords) {
        for (const keyword of rule.keywords) {
          const regex = new RegExp(keyword, 'gi');
          let match: RegExpExecArray | null;
          
          while ((match = regex.exec(text)) !== null) {
            findings.push({
              type: rule.type,
              value: match[0],
              masked: `[${rule.type.toUpperCase()}_REDACTED]`,
              position: {
                start: match.index,
                end: match.index + match[0].length
              }
            });
          }
        }
      }

      // Check pattern-based rules
      if (rule.pattern) {
        const regex = new RegExp(rule.pattern, 'gi');
        let match: RegExpExecArray | null;
        
        while ((match = regex.exec(text)) !== null) {
          findings.push({
            type: rule.type,
            value: match[0],
            masked: `[${rule.type.toUpperCase()}_REDACTED]`,
            position: {
              start: match.index,
              end: match.index + match[0].length
            }
          });
        }
      }
    }

    const triggered = findings.length > 0;
    return this.buildResult(
      triggered,
      triggered ? 'MASK' : 'ALLOW',
      findings
    );
  }

  /**
   * Apply masking to text based on CII rules
   * @param text - Original text containing CII
   * @returns Masked text with CII replaced by redaction placeholders
   */
  mask(text: string): string {
    const config = loadRules<CiiConfig>('cii-rules.json');
    let masked = text;

    for (const rule of config.rules) {
      if (!rule.enabled) continue;
      
      const redacted = `[${rule.type.toUpperCase()}_REDACTED]`;

      // Mask keywords
      if (rule.keywords) {
        for (const keyword of rule.keywords) {
          const regex = new RegExp(keyword, 'gi');
          masked = masked.replace(regex, redacted);
        }
      }

      // Mask patterns
      if (rule.pattern) {
        const regex = new RegExp(rule.pattern, 'gi');
        masked = masked.replace(regex, redacted);
      }
    }

    return masked;
  }
}
