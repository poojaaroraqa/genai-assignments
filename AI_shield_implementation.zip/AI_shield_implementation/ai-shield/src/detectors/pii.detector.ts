import { BaseDetector } from './base.detector';
import { DetectorResult, ModerationRequest, Finding, PiiRule } from '../types';
import { loadRules } from '../config/loader';

interface PiiRulesConfig {
  enabled: boolean;
  defaultAction: string;
  rules: PiiRule[];
}

/**
 * PII (Personally Identifiable Information) Detector
 * Detects and masks sensitive personal information like emails, phones, SSN, etc.
 */
export class PiiDetector extends BaseDetector {
  name = 'pii';

  /**
   * Detect PII in the provided text
   * @param request - Moderation request containing text to scan
   * @returns DetectorResult with findings and MASK action if PII detected
   */
  detect(request: ModerationRequest): DetectorResult {
    const config = loadRules<PiiRulesConfig>('pii-rules.json');
    
    if (!config.enabled) {
      return this.buildResult(false, 'ALLOW', []);
    }

    const text = request.text || '';
    const findings: Finding[] = [];

    // Iterate through all PII rules
    for (const rule of config.rules) {
      if (!rule.enabled) continue;
      
      const regex = new RegExp(rule.pattern, 'gi');
      let match: RegExpExecArray | null;
      
      // Find all matches in the text
      while ((match = regex.exec(text)) !== null) {
        findings.push({
          type: rule.type,
          value: match[0],
          masked: rule.mask,
          position: {
            start: match.index,
            end: match.index + match[0].length
          }
        });
      }
    }

    const triggered = findings.length > 0;
    return this.buildResult(
      triggered,
      triggered ? 'MASK' : 'ALLOW',
      findings
    );
  }

  /**
   * Apply masking to text based on PII rules
   * @param text - Original text containing PII
   * @returns Masked text with PII replaced by redaction placeholders
   */
  mask(text: string): string {
    const config = loadRules<PiiRulesConfig>('pii-rules.json');
    let masked = text;

    for (const rule of config.rules) {
      if (!rule.enabled) continue;
      
      const regex = new RegExp(rule.pattern, 'gi');
      masked = masked.replace(regex, rule.mask);
    }

    return masked;
  }
}
