import { BaseDetector } from './base.detector';
import { DetectorResult, ModerationRequest, FileRule } from '../types';
import { loadRules } from '../config/loader';
import mime from 'mime-types';
import path from 'path';

interface FileConfig extends FileRule {
  enabled: boolean;
}

/**
 * File Validator
 * Validates uploaded files based on:
 * - File extension (whitelist)
 * - MIME type (whitelist)
 * - File size (max limit)
 * BLOCKS files that don't meet validation criteria
 */
export class FileDetector extends BaseDetector {
  name = 'file';

  /**
   * Validate uploaded file
   * @param request - Moderation request (not used for file validation)
   * @param file - Multer file object to validate
   * @returns DetectorResult with findings and BLOCK action if validation fails
   */
  detect(_request: ModerationRequest, file?: Express.Multer.File): DetectorResult {
    const config = loadRules<FileConfig>('file-rules.json');
    
    if (!config.enabled) {
      return this.buildResult(false, 'ALLOW', []);
    }

    // If no file uploaded, allow (validation handled by route)
    if (!file) {
      return this.buildResult(false, 'ALLOW', [], 'No file uploaded');
    }

    const findings = [];
    const ext = path.extname(file.originalname).toLowerCase();
    const detectedMime = mime.lookup(file.originalname) || file.mimetype;

    // Validate file extension
    if (!config.allowedExtensions.includes(ext)) {
      findings.push({
        type: 'invalid_extension',
        value: ext
      });
    }

    // Validate MIME type
    if (!config.allowedMimeTypes.includes(detectedMime as string)) {
      findings.push({
        type: 'invalid_mime_type',
        value: detectedMime as string
      });
    }

    // Validate file size
    if (file.size > config.maxFileSizeBytes) {
      findings.push({
        type: 'file_too_large',
        value: `${file.size} bytes`,
        masked: `Max allowed: ${config.maxFileSizeBytes} bytes`
      });
    }

    const triggered = findings.length > 0;
    
    return this.buildResult(
      triggered,
      triggered ? 'BLOCK' : 'ALLOW',
      findings,
      triggered ? 'File validation failed' : 'File is valid'
    );
  }
}
