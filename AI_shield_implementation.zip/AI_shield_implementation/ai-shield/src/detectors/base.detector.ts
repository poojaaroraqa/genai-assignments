import { DetectorResult, ModerationRequest } from '../types';

/**
 * Abstract base class for all detectors
 * All detector implementations must extend this class
 */
export abstract class BaseDetector {
  abstract name: string;
  
  /**
   * Main detection method to be implemented by each detector
   * @param request - The moderation request containing text and optional model
   * @param file - Optional file for file-based detectors
   * @returns DetectorResult with findings and action
   */
  abstract detect(request: ModerationRequest, file?: Express.Multer.File): DetectorResult;

  /**
   * Helper method to build standardized detector results
   * @param triggered - Whether the detector found any violations
   * @param action - The action to take (ALLOW, MASK, BLOCK)
   * @param findings - Array of findings
   * @param message - Optional message describing the result
   */
  protected buildResult(
    triggered: boolean,
    action: DetectorResult['action'],
    findings: DetectorResult['findings'],
    message?: string
  ): DetectorResult {
    return {
      detector: this.name,
      triggered,
      action,
      findings,
      message
    };
  }
}
