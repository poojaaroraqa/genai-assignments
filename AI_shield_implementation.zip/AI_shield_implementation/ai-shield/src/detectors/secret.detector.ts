import { BaseDetector } from './base.detector';
import { DetectorResult, ModerationRequest, Finding, SecretRule } from '../types';
import { loadRules } from '../config/loader';

interface SecretConfig {
  enabled: boolean;
  defaultAction: string;
  rules: SecretRule[];
}

/**
 * Secret Detector
 * Detects API keys, tokens, and other secrets in text
 * BLOCKS requests entirely when secrets are detected (no masking)
 */
export class SecretDetector extends BaseDetector {
  name = 'secret';

  /**
   * Detect secrets in the provided text
   * @param request - Moderation request containing text to scan
   * @returns DetectorResult with findings and BLOCK action if secrets detected
   */
  detect(request: ModerationRequest): DetectorResult {
    const config = loadRules<SecretConfig>('secret-rules.json');
    
    if (!config.enabled) {
      return this.buildResult(false, 'ALLOW', []);
    }

    const text = request.text || '';
    const findings: Finding[] = [];

    // Iterate through all secret detection rules
    for (const rule of config.rules) {
      if (!rule.enabled) continue;
      
      const regex = new RegExp(rule.pattern, 'gi');
      let match: RegExpExecArray | null;
      
      // Find all matches in the text
      while ((match = regex.exec(text)) !== null) {
        // Partially obfuscate the secret in findings for security
        const value = match[0];
        const obfuscatedValue = value.length > 6 
          ? `${value.substring(0, 6)}****` 
          : '****';
        
        findings.push({
          type: rule.type,
          value: obfuscatedValue,
          masked: '[SECRET_REDACTED]',
          position: {
            start: match.index,
            end: match.index + match[0].length
          }
        });
      }
    }

    const triggered = findings.length > 0;
    
    return this.buildResult(
      triggered,
      triggered ? 'BLOCK' : 'ALLOW',
      findings,
      triggered ? 'Request blocked: secrets detected in payload' : undefined
    );
  }
}
