import { BaseDetector } from './base.detector';
import { DetectorResult, ModerationRequest, Finding, ToxicRule, SeverityLevel } from '../types';
import { loadRules } from '../config/loader';

interface ToxicConfig {
  enabled: boolean;
  defaultAction: string;
  categories: ToxicRule[];
  blockOnSeverity: SeverityLevel[];
}

/**
 * Toxic Content Detector
 * Detects toxic content (hate speech, threats, harassment, profanity)
 * Blocks based on severity level configuration
 */
export class ToxicDetector extends BaseDetector {
  name = 'toxic';

  /**
   * Detect toxic content in the provided text
   * @param request - Moderation request containing text to scan
   * @returns DetectorResult with findings and BLOCK/ALLOW action based on severity
   */
  detect(request: ModerationRequest): DetectorResult {
    const config = loadRules<ToxicConfig>('toxic-rules.json');
    
    if (!config.enabled) {
      return this.buildResult(false, 'ALLOW', []);
    }

    const text = request.text?.toLowerCase() || '';
    const findings: Finding[] = [];

    // Check each toxic category
    for (const category of config.categories) {
      if (!category.enabled) continue;
      
      // Check for keyword matches in this category
      for (const keyword of category.keywords) {
        if (text.includes(keyword.toLowerCase())) {
          findings.push({
            type: category.category,
            value: keyword,
            severity: category.severity
          });
        }
      }
    }

    // If no toxic content found, allow
    if (findings.length === 0) {
      return this.buildResult(false, 'ALLOW', []);
    }

    // Determine if we should block based on severity levels
    const shouldBlock = findings.some(finding =>
      finding.severity && config.blockOnSeverity.includes(finding.severity)
    );

    const message = shouldBlock
      ? 'Request blocked: toxic content detected'
      : 'Low severity toxic content - allowed';

    return this.buildResult(
      true,
      shouldBlock ? 'BLOCK' : 'ALLOW',
      findings,
      message
    );
  }
}
