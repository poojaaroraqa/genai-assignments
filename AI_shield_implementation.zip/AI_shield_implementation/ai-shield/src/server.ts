import app from './app';
import dotenv from 'dotenv';
import logger from './utils/logger';

dotenv.config();

const PORT = process.env.PORT || 4000;

app.listen(PORT, () => {
  console.log(`🛡️  AI-Shield running on http://localhost:${PORT}`);
  logger.info(`AI-Shield server started`, { port: PORT, env: process.env.NODE_ENV || 'development' });
});
