# Test script for Secret Detection endpoint
Write-Host "Testing Secret Detection Endpoint" -ForegroundColor Cyan
Write-Host "==================================`n" -ForegroundColor Cyan

# Test 1: Multiple secret types detected (BLOCK)
Write-Host "Test 1: Detect Secrets (OpenAI key, JWT) - Should BLOCK" -ForegroundColor Yellow
$body1 = @{
    text = "Use this key: sk-abc123XYZ456abc123XYZ456abc123XY to call the API. Also Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.test.signature"
} | ConvertTo-Json

try {
    $response1 = Invoke-RestMethod -Uri "http://localhost:4000/api/detect/secret" -Method Post -Body $body1 -ContentType "application/json" -ErrorAction Stop
    if ($response1.action -eq "BLOCK") {
        Write-Host "✓ Status: $($response1.status)" -ForegroundColor Green
        Write-Host "✓ Action: $($response1.action)" -ForegroundColor Green
        Write-Host "✓ HTTP Status: 422 (Unprocessable Entity)" -ForegroundColor Green
        Write-Host "✓ Findings: $($response1.detectorResults[0].findings.Count)" -ForegroundColor Green
        Write-Host "✓ Message: $($response1.detectorResults[0].message)" -ForegroundColor Green
        Write-Host "✓ Sanitized Content: $($response1.sanitizedContent)" -ForegroundColor Green
        Write-Host ""
    } else {
        Write-Host "✗ Expected BLOCK but got $($response1.action)" -ForegroundColor Red
    }
} catch {
    if ($_.Exception.Response.StatusCode -eq 422) {
        Write-Host "✓ Correctly returned 422 Unprocessable Entity" -ForegroundColor Green
        Write-Host ""
    } else {
        Write-Host "✗ Test 1 Failed: $_" -ForegroundColor Red
    }
}

# Test 2: AWS and GitHub tokens
Write-Host "Test 2: Detect Secrets (AWS key, GitHub token) - Should BLOCK" -ForegroundColor Yellow
$body2 = @{
    text = "AWS credentials: AKIAIOSFODNN7EXAMPLE and GitHub token: ghp_1234567890abcdefghijklmnopqrstuvwxyz"
} | ConvertTo-Json

try {
    $response2 = Invoke-RestMethod -Uri "http://localhost:4000/api/detect/secret" -Method Post -Body $body2 -ContentType "application/json" -ErrorAction Stop
    if ($response2.action -eq "BLOCK") {
        Write-Host "✓ Action: BLOCK" -ForegroundColor Green
        Write-Host "✓ Findings: $($response2.detectorResults[0].findings.Count)" -ForegroundColor Green
        Write-Host ""
    }
} catch {
    if ($_.Exception.Response.StatusCode -eq 422) {
        Write-Host "✓ Correctly returned 422" -ForegroundColor Green
        Write-Host ""
    }
}

# Test 3: Generic secret pattern
Write-Host "Test 3: Detect Generic Secret (password=) - Should BLOCK" -ForegroundColor Yellow
$body3 = @{
    text = "Login with password=MySecretPass123! to access the system"
} | ConvertTo-Json

try {
    $response3 = Invoke-RestMethod -Uri "http://localhost:4000/api/detect/secret" -Method Post -Body $body3 -ContentType "application/json" -ErrorAction Stop
    if ($response3.action -eq "BLOCK") {
        Write-Host "✓ Action: BLOCK" -ForegroundColor Green
        Write-Host "✓ Generic secret pattern detected" -ForegroundColor Green
        Write-Host ""
    }
} catch {
    if ($_.Exception.Response.StatusCode -eq 422) {
        Write-Host "✓ Correctly returned 422" -ForegroundColor Green
        Write-Host ""
    }
}

# Test 4: Clean text (no secrets)
Write-Host "Test 4: Clean Text (No secrets) - Should ALLOW" -ForegroundColor Yellow
$body4 = @{
    text = "Please contact support for API access credentials."
} | ConvertTo-Json

try {
    $response4 = Invoke-RestMethod -Uri "http://localhost:4000/api/detect/secret" -Method Post -Body $body4 -ContentType "application/json"
    Write-Host "✓ Status: $($response4.status)" -ForegroundColor Green
    Write-Host "✓ Action: $($response4.action)" -ForegroundColor Green
    Write-Host "✓ Findings: $($response4.detectorResults[0].findings.Count)" -ForegroundColor Green
    Write-Host "✓ HTTP Status: 200" -ForegroundColor Green
    Write-Host ""
} catch {
    Write-Host "✗ Test 4 Failed: $_" -ForegroundColor Red
}

# Test 5: Missing text field (validation error)
Write-Host "Test 5: Validation Error (Missing text field)" -ForegroundColor Yellow
$body5 = @{} | ConvertTo-Json

try {
    $response5 = Invoke-RestMethod -Uri "http://localhost:4000/api/detect/secret" -Method Post -Body $body5 -ContentType "application/json" -ErrorAction Stop
    Write-Host "✗ Should have failed but didn't" -ForegroundColor Red
} catch {
    if ($_.Exception.Response.StatusCode -eq 400) {
        Write-Host "✓ Correctly returned 400 Bad Request" -ForegroundColor Green
    } else {
        Write-Host "✗ Unexpected error: $_" -ForegroundColor Red
    }
}

Write-Host "`n==================================`n" -ForegroundColor Cyan
Write-Host "Key Difference: Secret detector returns 422 (not 200) when secrets found!" -ForegroundColor Yellow
Write-Host "All Tests Completed!" -ForegroundColor Cyan
